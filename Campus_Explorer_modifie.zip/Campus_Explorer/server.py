"""Serveur local de Campus Explorer — Python 3, bibliothèque standard."""
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit
import argparse
import json
import time

ROOT = Path(__file__).resolve().parent
PRODUCTS_FILE = ROOT / "data" / "products.json"


def load_products():
    return json.loads(PRODUCTS_FILE.read_text(encoding="utf-8"))


def prepare_catalogue(products):
    """Retourne uniquement les données utiles à l’interface."""
    return products

class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT), **kwargs)

    def send_json(self, data, status=200):
        payload = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(payload)))
        self.send_header("Cache-Control", "no-cache")
        self.end_headers()
        self.wfile.write(payload)

    def do_GET(self):
        path = urlsplit(self.path).path
        if path == "/api/products":
            products = load_products()
            self.send_json(prepare_catalogue(products))
        elif path == "/api/stats":
            products = load_products()
            self.send_json({
                "sessions": len(products),
                "campuses": len({p["campus"] for p in products}),
                "organizers": len({p["organizer"] for p in products}),
                "updatedAt": time.strftime("%H:%M:%S"),
            })
        elif path.startswith("/api/"):
            self.send_json({"error": "Ressource introuvable."}, 404)
        else:
            super().do_GET()


def main():
    parser = argparse.ArgumentParser(description="Campus Explorer — serveur local")
    parser.add_argument("--port", type=int, default=8000)
    args = parser.parse_args()
    server = ThreadingHTTPServer(("127.0.0.1", args.port), Handler)
    print(f"Campus Explorer : http://localhost:{args.port}", flush=True)
    print("Arrêter le serveur : Ctrl+C", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
