# TP : écoconception de Campus Explorer

## Travail demandé

Campus Explorer présente des activités et des services sur cinq campus. Vous disposez de trois heures, en binôme, pour réduire les ressources nécessaires à son fonctionnement.

Relevez **5 problèmes**, dont **3 reliés à des critères du RGESN 2024**. Réalisez ensuite **2 ou 3 modifications** et vérifiez leurs effets. Vous n’avez pas à tout corriger.

Vous pouvez réorganiser le code (refactoring), réduire les traitements et transferts, ou retirer une fonction peu utile. Expliquez ce que vous améliorez : un code plus lisible ne consomme pas nécessairement moins de ressources.

Le catalogue présente des sessions de septembre à décembre 2026. Les données et coordonnées sont fictives ; aucune inscription ni réservation n’est enregistrée.

## Démarrer le site

Prévoyez Python 3.10+ et un navigateur avec ses outils de développement : Chrome, Edge, Firefox ou équivalent. Les bases de HTML, CSS, JavaScript et HTTP sont nécessaires. La [fiche d’aide](FICHE_MESURE.md) explique comment utiliser Network / Réseau ; Lighthouse est facultatif.

1. Extrayez complètement le dossier reçu.
2. Ouvrez un terminal dans le dossier qui contient `server.py`.
3. Lancez le serveur :

```console
python server.py
```

4. Ouvrez http://localhost:8000 et laissez le terminal ouvert. Pour arrêter le serveur, utilisez Ctrl+C.

Sous Windows, essayez `py -3 server.py` si `python` n’est pas reconnu. Sous macOS/Linux, utilisez `python3 server.py`. Si le port est occupé, lancez `python server.py --port 8001` et ouvrez http://localhost:8001.

Aucune dépendance à installer ni connexion Internet nécessaire. Ne double-cliquez pas sur `index.html` et n’utilisez pas Live Server : l’API Python est indispensable.

Redémarrez le serveur après un changement du Python ou du JSON ; rechargez la page pour le HTML, le CSS ou le JavaScript. Le serveur reste local : utilisez l’émulation du navigateur pour tester le mobile.

## Fichiers utiles

| Fichier ou dossier | Contenu |
|---|---|
| `index.html` | Structure de la page |
| `styles.css` | Présentation et adaptation aux écrans |
| `app.js` | Affichage, recherche et interactions |
| `server.py` | Serveur HTTP et API |
| `data/products.json` | Catalogue des sessions |
| `assets/` | Images et icône |
| `FICHE_MESURE.md` | Aide aux vérifications, rien à remplir |

## Fonctionnalités à conserver

Votre version doit toujours permettre de :

1. Consulter toutes les sessions. N’en supprimez pas pour alléger le catalogue.
2. Rechercher dans les titres, résumés, descriptions et lieux, sans distinction de casse ou d’accents. Pour une recherche de plusieurs mots, tous doivent être présents, dans n’importe quel ordre.
3. Combiner recherche, catégorie et campus, puis réinitialiser les filtres.
4. Lire une fiche complète : description, lieu, date, heure, durée, tarif, organisateur et modalités de participation.
5. Distinguer une recherche sans résultat d’un échec de chargement.
6. Consulter les résultats dans l’ordre des dates et heures.

Testez aussi à 360 px et au clavier. Signalez les défauts préexistants laissés en place et corrigez toute régression introduite. Un audit complet d’accessibilité n’est pas demandé.

Vous pouvez changer la présentation et les fonctions secondaires, en justifiant les suppressions. Aucun paiement, compte utilisateur ou système de réservation réel n’est à développer.

## Utiliser le RGESN

Utilisez le Référentiel général d’écoconception de services numériques, édition 2024 : [critères de l’Arcep](https://www.arcep.fr/mes-demarches-et-services/entreprises/fiches-pratiques/referentiel-general-ecoconception-services-numeriques.html) ou [PDF officiel](https://www.arcep.fr/uploads/tx_gspublication/referentiel_general_ecoconception_des_services_numeriques_version_2024.pdf), également disponible sur l’ENT.

Pour chacun des trois rattachements, indiquez le numéro et l’intitulé du critère, votre observation et le lien entre les deux. Lisez son moyen de contrôle avant de conclure. Des problèmes distincts peuvent relever du même critère.

Un sujet impossible à vérifier ici est « non évaluable », pas forcément « non applicable » ; il ne remplace pas un problème observé. Ce TP n’est pas un audit complet du RGESN.

## Déroulement

| Étape | Durée | Travail à effectuer |
|---|---:|---|
| Démarrage | 20 min | Lancer le site et observer son chargement dans Network |
| Audit | 30 min | Relever 5 problèmes, dont 3 liens au RGESN |
| Choix des modifications | 15 min | Comparer gain attendu, effort et risque |
| Modifications et vérifications | 90 min | Réaliser et tester 2 ou 3 modifications |
| Compte rendu | 25 min | Préparer les diapositives et l’annexe courte |

Expliquez pourquoi vous écartez au moins une autre modification. Modifier le serveur n’est pas obligatoire. Demandez un indice si vous êtes bloqués.

Utilisez la [fiche d’aide](FICHE_MESURE.md) pour comparer un chargement, puis vérifier vos changements dans les mêmes conditions. Elle ne se remplit pas et n’est pas à rendre.

## Rendu

Remettez le code, trois diapositives maximum et une annexe courte :

1. **Diagnostic** : principaux problèmes et liens au RGESN.
2. **Modifications** : choix retenus, changements, action écartée et suppressions éventuelles.
3. **Bilan** : fonctionnement vérifié et limites restantes.

L’annexe liste les cinq problèmes avec une preuve courte (observation ou emplacement dans le code) et les trois rattachements au RGESN. Un fichier `.txt`, `.md` ou un tableur convient. Aucun tableau de mesures ni protocole à remettre, dans l’annexe ou les diapositives.

Expliquez ce que vos changements apportent. Une baisse des transferts ou du temps de calcul n’est pas une mesure d’énergie ou de CO₂.
