# Aide aux vérifications

Cette page sert pendant le TP. Rien à remplir ni à rendre. Commencez avec Network / Réseau ; utilisez les autres outils seulement s’ils vous aident à comprendre un problème.

## Observer le chargement

1. Ouvrez le site, puis les outils de développement (F12) et l’onglet Network / Réseau. Gardez la même machine, le même navigateur et la même taille de fenêtre avant/après. N’appliquez pas de ralentissement réseau ou processeur.
2. Retirez les filtres, décochez Preserve log / Conserver le journal et cochez Disable cache / Désactiver le cache. Videz le journal et activez l’enregistrement.
3. Rechargez la page et attendez 30 secondes, sans défiler ni interagir. Arrêtez l’enregistrement. Si le site ne charge pas dans ce délai, choisissez une durée plus longue et reprenez les deux relevés avec cette durée.
4. Regardez les ressources les plus lourdes, le total transféré et le nombre d’entrées réseau. Gardez une note personnelle pour refaire la comparaison après vos modifications.

Relevez le volume **transféré**, pas la taille décodée. Effacer le journal n’efface pas le cache ; une entrée provenant du cache ne correspond pas forcément à un appel au serveur.

## Vérifier une modification

Choisissez une vérification adaptée, sans multiplier les scénarios :

- **Images** : comparez le poids transféré et le rendu à la même taille d’écran.
- **Requêtes** : refaites la même recherche, à la même cadence, ou attendez la même durée sans interaction. Comparez les appels envoyés.
- **Cache** : décochez Disable cache. Rechargez une fois pour le remplir, puis une seconde fois normalement pour observer sa réutilisation. Faites la même chose avant/après, sans rechargement forcé.
- **Affichage ou organisation du code** : comparez le comportement et le travail évité. Si aucun gain de ressources n’est démontré, dites-le simplement.

Refaites aussi quelques actions : chercher `rustine` (25 résultats), filtrer Rangueil (5), ouvrir puis fermer une fiche et consulter les résultats suivants. Vérifiez les fonctions touchées par vos changements, ainsi que le parcours au clavier et à 360 px. Signalez les défauts déjà présents ; corrigez ceux que vous introduisez.

## Outils facultatifs

Lighthouse fonctionne sur localhost dans Chrome et Edge. Si vous l’utilisez, gardez les mêmes options avant/après. Son audit de chargement ne couvre pas toutes les interactions, et ses conditions diffèrent de celles de Network. Performance peut aider à repérer un traitement lent.

EcoIndex reste facultatif : son service distant ne peut pas accéder à votre localhost. N’exposez pas le serveur sur Internet ; utilisez une solution locale uniquement

Ces observations aident à vérifier vos choix. Elles ne mesurent ni l’énergie ni les émissions de CO₂, et un meilleur score ne prouve pas une conformité au RGESN.
