let products = [];
let productsById = new Map();
let requestNumber = 0;
let visibleCount = 24;
let filteredCount = 0;

const dateFormat = new Intl.DateTimeFormat("fr-FR", {
  day: "numeric", month: "short", year: "numeric"
});
const priceFormat = new Intl.NumberFormat("fr-FR", {
  style: "currency", currency: "EUR", maximumFractionDigits: 2
});

function normalize(text) {
  return text.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
}

function formatDate(product) {
  return dateFormat.format(new Date(product.date + "T12:00:00")) + " · " + product.time;
}

function formatPrice(price) {
  return price === 0 ? "Gratuit" : priceFormat.format(price);
}

function addText(parent, tag, text, className = "") {
  const element = document.createElement(tag);
  element.textContent = text;
  element.className = className;
  parent.append(element);
  return element;
}

function readFilters() {
  return {
    words: normalize(document.getElementById("search").value.trim()).split(/\s+/).filter(Boolean),
    category: document.getElementById("category").value,
    campus: document.getElementById("campus").value
  };
}

function filterProducts(items, filters) {
  return items.filter(product => {
    const text = normalize([
      product.title, product.summary, product.description, product.location, product.campus
    ].join(" "));
    return filters.words.every(word => text.includes(word))
      && (!filters.category || product.category === filters.category)
      && (!filters.campus || product.campus === filters.campus);
  }).sort((a, b) => a.date.localeCompare(b.date) || a.time.localeCompare(b.time) || a.id - b.id);
}

function createCard(product) {
  const card = document.createElement("div");
  card.className = "card";
  card.dataset.category = product.category;
  card.dataset.id = product.id;
  const top = addText(card, "div", "", "card-top");
  addText(top, "span", product.category, "category-badge");
  addText(top, "span", formatPrice(product.price), "price");
  addText(card, "h3", product.title);
  addText(card, "p", product.description, "description");
  const footer = addText(card, "div", "", "card-footer");
  addText(footer, "p", formatDate(product), "meta");
  addText(footer, "p", product.location, "meta");
  const action = addText(footer, "button", "Voir les informations ↗", "card-action");
  action.type = "button";
  action.addEventListener("click", () => openDetails(product.id));
  return card;
}

function updateVisibleCards() {
  document.querySelectorAll("#results .card").forEach((card, index) => {
    card.hidden = index >= visibleCount;
  });
  document.getElementById("count").textContent = `${Math.min(visibleCount, filteredCount)} rendez-vous affichés sur ${filteredCount}`;
  document.getElementById("more").hidden = visibleCount >= filteredCount;
}

function showMore() {
  visibleCount += 24;
  updateVisibleCards();
}

async function loadCatalogue() {
  const current = ++requestNumber;
  document.getElementById("count").textContent = "Chargement du programme…";
  document.getElementById("error").hidden = true;
  document.getElementById("retry").hidden = true;
  try {
    const response = await fetch("/api/products");
    if (!response.ok) throw new Error("Catalogue indisponible");
    products = await response.json();
    if (current !== requestNumber) return;
    productsById = new Map(products.map(product => [product.id, product]));
    const categories = [...new Set(products.map(product => product.category))].sort();
    const categorySelect = document.getElementById("category");
    categorySelect.replaceChildren(new Option("Toutes les envies", ""));
    for (const category of categories) {
      const count = products.filter(product => product.category === category).length;
      categorySelect.add(new Option(`${category} (${count})`, category));
    }
    renderCatalogue();
  } catch (error) {
    if (current !== requestNumber) return;
    document.getElementById("count").textContent = "Programme indisponible";
    document.getElementById("results").replaceChildren();
    document.getElementById("empty").hidden = true;
    document.getElementById("error").textContent = "Impossible de charger le programme. Vérifiez que le serveur est démarré, puis réessayez.";
    document.getElementById("error").hidden = false;
    document.getElementById("retry").hidden = false;
  }
}

function renderCatalogue() {
  const items = filterProducts(products, readFilters());
  filteredCount = items.length;
  visibleCount = 24;
  const root = document.getElementById("results");
  root.replaceChildren();
  for (const product of items) root.append(createCard(product));
  updateVisibleCards();
  document.getElementById("empty").hidden = items.length !== 0;
}

function onSearch() {
  if (products.length) renderCatalogue();
}

function resetFilters() {
  for (const id of ["search", "category", "campus"]) document.getElementById(id).value = "";
  renderCatalogue();
}

function openDetails(id) {
  const product = productsById.get(id);
  if (!product) return;
  document.getElementById("detail-title").textContent = product.title;
  document.getElementById("detail-category").textContent = product.category;
  document.getElementById("detail-summary").textContent = product.summary;
  document.getElementById("detail-description").textContent = product.description;
  document.getElementById("detail-access").textContent = product.access;
  document.getElementById("detail-registration").textContent = product.registration;
  document.getElementById("detail-contact").textContent = `${product.organizer} · ${product.contact}`;
  const facts = document.getElementById("detail-facts");
  facts.replaceChildren();
  for (const [label, value] of [
    ["Quand", formatDate(product)], ["Durée", `${product.duration} minutes`],
    ["Où", product.location], ["Adresse", product.address], ["Tarif", formatPrice(product.price)]
  ]) {
    addText(facts, "dt", label);
    addText(facts, "dd", value);
  }
  document.getElementById("related-section").hidden = true;
  const dialog = document.getElementById("activity-dialog");
  if (!dialog.open) dialog.showModal();
  dialog.scrollTop = 0;
}

function refreshStats() {
  // Les statistiques sont calculées depuis le catalogue déjà chargé : aucun appel réseau périodique.
  const campuses = new Set(products.map(product => product.campus));
  const organizers = new Set(products.map(product => product.organizer));
  document.getElementById("stat-sessions").textContent = products.length;
  document.getElementById("stat-campuses").textContent = campuses.size;
  document.getElementById("stat-organizers").textContent = organizers.size;
  document.getElementById("stats-status").textContent = "Calculé à partir du catalogue chargé.";
}

function subscribe() {
  document.getElementById("newsletter-email").value = "";
  document.getElementById("newsletter-status").textContent = "Mode démonstration : aucune adresse n’est envoyée ni enregistrée.";
}


window.addEventListener("DOMContentLoaded", () => {
  document.getElementById("activity-dialog").addEventListener("close", () => {
    for (const id of ["search", "category", "campus"]) document.getElementById(id).value = "";
    visibleCount = 24;
    renderCatalogue();
    document.getElementById("catalogue").scrollIntoView();
  });
  document.getElementById("refresh-stats").addEventListener("click", refreshStats);
  loadCatalogue().then(() => { if (products.length) refreshStats(); });
});
