@echo off

copy _php.ini C:\tools\php85\php.ini
copy _symfony.exe C:\tools\php85\symfony.exe

php testinstall.php
php composer.phar --version
symfony version

pause
